//
//  MovieListPresenter.swift
//  CodableExample
//
//  Created by Enes Urkan on 15.07.2023.
//

import UIKit

protocol MovieListPresentationLogic {
    func present(_ response: MovieListModels.Response)
}

final class MovieListPresenter: MovieListPresentationLogic {
    // MARK: Properties
    weak var controller: MovieListViewControllerDisplayLogic?

    // MARK: Presentation Logic
    
    func present(_ response: MovieListModels.Response) {
        switch response.result {
        case .success(let movieList):
            let movieListDisplayModels = movieList.compactMap({ MovieListDisplayModel(movie: $0)})
            let viewModel = MovieListModels.ViewModel(cellModels: movieListDisplayModels)
            controller?.display(viewModel: viewModel)
//            encodeExample(movieList.first)
        case .failure(let error):
            controller?.display(error: error.description)
        }
    }
    
//    func encodeExample(_ movie: Movie?) {
//        guard let movie else { return }
//        // Encode Example
//        let encoder = JSONEncoder()
//        guard let encoded = try? encoder.encode(movie) else { return }
//        do {
//            let json = try JSONSerialization.jsonObject(with: encoded, options: .mutableContainers) as? [String:Any]
//            print(json)
//        } catch {
//            print("Something went wrong")
//        }
//    }
}


