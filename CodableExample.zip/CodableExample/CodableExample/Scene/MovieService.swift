//
//  MovieService.swift
//  CodableExample
//
//  Created by Enes Urkan on 16.07.2023.
//

import Foundation

final class MovieService {
    func getMovieList(completion: (Result<[Movie], DecodeError>) -> Void) {
        self.decode([Movie].self, from: "MovieData.json", dateDecodingStrategy: .millisecondsSince1970, completion: completion)
        // Uygulama içerisinde farklı servis yapıları kullanılabilir. Bunlar için custom decoding yazıp, hangi decode'u kullanacağını verebilirsiniz.
//        self.decode([Movie].self, from: "MovieData-.json", dateDecodingStrategy: .millisecondsSince1970, keyDecodingStrategy: .convertFromWinstonSlenderBlue, completion: completion)
//        self.decode([Movie].self, from: "MovieData?.json", dateDecodingStrategy: .millisecondsSince1970, keyDecodingStrategy: .convertFromKentDrangeGray, completion: completion)
    }
}

extension MovieService {
    enum DecodeError: Error {
        case filePath
        case load
        case keyNotFound(String)
        case typeMismatch(String)
        case valueNotFound(String)
        case dataCorrupted(String)
        case general(String)
        
        var description: String {
            switch self {
            case .filePath:
                return "Verilen json path hatalı!"
            case .load:
                return "Data yüklenemedi."
            case .dataCorrupted(let description):
                return description
            case .keyNotFound(let description):
                return description
            case .typeMismatch(let description):
                return description
            case .valueNotFound(let description):
                return description
            case .general(let description):
                return description
            }
        }
    }
    
    private func decode<T: Decodable>(_ type: T.Type,
                              from file: String,
                              dateDecodingStrategy: JSONDecoder.DateDecodingStrategy = .deferredToDate,
                              keyDecodingStrategy: JSONDecoder.KeyDecodingStrategy = .useDefaultKeys,
                              completion: (Result<T, DecodeError>) -> Void) {
        guard let url = Bundle.main.url(forResource: file, withExtension: nil) else {
            return completion(.failure(.filePath))
        }

        guard let data = try? Data(contentsOf: url) else {
            return completion(.failure(.load))
        }

        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = dateDecodingStrategy
        decoder.keyDecodingStrategy = keyDecodingStrategy

        do {
            let object = try decoder.decode(T.self, from: data)
            return completion(.success(object))
        } catch DecodingError.keyNotFound(let key, let context) {
            return completion(.failure(.keyNotFound("Failed to decode from bundle due to missing key '\(key.stringValue)' not found – \(context.debugDescription)")))
        } catch DecodingError.typeMismatch(_, let context) {
            return completion(.failure(.typeMismatch("Failed to decode from bundle due to type mismatch – \(context.debugDescription)")))
        } catch DecodingError.valueNotFound(let type, let context) {
            return completion(.failure(.valueNotFound("Failed to decode from bundle due to missing \(type) value – \(context.debugDescription)")))
        } catch DecodingError.dataCorrupted(_) {
            return completion(.failure(.dataCorrupted("Failed to decode from bundle because it appears to be invalid JSON")))
        } catch {
            return completion(.failure(.general("Failed to decode from bundle: \(error.localizedDescription)")))
        }
    }
}
