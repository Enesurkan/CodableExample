//
//  MovieListModels.swift
//  CodableExample
//
//  Created by Enes Urkan on 15.07.2023.
//

import Foundation

enum MovieListModels {
    struct Response {
        let result: Result<[Movie], MovieService.DecodeError>
    }
    
    struct ViewModel {
        let cellModels: [MovieListDisplayModel]
    }
}

struct Movie: Codable {
    var id : Int
    var title : String
    var director : String
    var actors : String
    var plot : String
    var posterUrl : URL?
    var date : Date?
    var movieType: MovieType
    var detail: MovieDetail?
    
    var detailName: String
    
    enum CodingKeys: String, CodingKey {
        
        case id = "id"
        case title = "title"
        case director = "director"
        case actors = "actors"
        case plot = "plot"
        case posterUrl = "posterUrl"
        case date = "date"
        case movieType = "movieType"
        case detail = "detail"
        
//        // Submodeli tutmayıp, sadece içeriden ilgili property'leri bu enum'ı kullanarak alabiliriz.
//        enum MovieDetailCodingKeys: String, CodingKey {
//            case id = "id"
//            case title = "title"
//            case director = "director"
//        }
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        // Return değerini '!' kabul ediyoruz
        id = try container.decode(Int.self, forKey: .id)
        // Return değerini '?' kabul ediyoruz
        title = try container.decodeIfPresent(String.self, forKey: .title) ?? ""
        director = try container.decode(String.self, forKey: .director)
        actors = try container.decode(String.self, forKey: .actors)
        plot = try container.decode(String.self, forKey: .plot)
        // URL karşılama
        posterUrl = try container.decodeIfPresent(URL.self, forKey: .posterUrl)
        // Date karşılama
        date = try container.decodeIfPresent(Date.self, forKey: .date)
        // Enum karşılama
        movieType = try container.decode(MovieType.self, forKey: .movieType)
        // Submodel altından bir objeye ihtiyacımız olduğunda 2 seçenek var.
        // Gelen submodel'i tam olarak maplemek ve kullanacağımız yerde ".name" gibi kullanabiliriz.
        detail = try container.decodeIfPresent(MovieDetail.self, forKey: .detail)
        // Ya da submodel'i self'te tutmayıp, ihtiyacımız olan property'i alt taraftaki gibi alabiliriz.
        let detailContainer = try container.nestedContainer(keyedBy: MovieDetail.CodingKeys.self, forKey: .detail)
        detailName = try detailContainer.decode(String.self, forKey: MovieDetail.CodingKeys.title)
        
//        let detailContainer = try container.nestedContainer(keyedBy: CodingKeys.MovieDetailCodingKeys.self, forKey: .detail)
//        detailName = try detailContainer.decode(String.self, forKey: CodingKeys.MovieDetailCodingKeys.title)
        #warning("Burada date'i formatlanmış bir şekilde koyabilir miyiz? Araştır")
        #warning("ios11'de de aynı şekilde çalışıyor mu? Kontrol et")
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(title, forKey: .title)
        try container.encode(director, forKey: .director)
        try container.encode(actors, forKey: .actors)
        try container.encode(plot, forKey: .plot)
        try container.encodeIfPresent(date, forKey: .date) // Epoch isterlerse .timeIntervalSince1970
        try container.encodeIfPresent(posterUrl?.absoluteString, forKey: .posterUrl)
        try container.encodeIfPresent(movieType, forKey: .movieType)
        try container.encodeIfPresent(detail, forKey: .detail)
    }
}

extension Movie {
    enum MovieType: String, Codable {
        case unknown
        case comedy = "Comedy"
        case fantasy = "Fantasy"
        
        init(from decoder: Decoder) throws {
            let container = try decoder.singleValueContainer()
            let decodedString = try container.decode(String.self)
            self = MovieType(rawValue: decodedString) ?? .unknown
        }
        
        func encode(to encoder: Encoder) throws {
            var container = encoder.singleValueContainer()
            try container.encode(self.rawValue)
        }
    }
}

struct MovieDetail: Codable {
    var id : Int
    var title : String
    var director : String
    
    enum CodingKeys: String, CodingKey {
        case id = "id"
        case title = "title"
        case director = "director"
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        id = try container.decodeIfPresent(Int.self, forKey: .id) ?? 0
        title = try container.decodeIfPresent(String.self, forKey: .title) ?? ""
        director = try container.decodeIfPresent(String.self, forKey: .director) ?? ""
    }
}
