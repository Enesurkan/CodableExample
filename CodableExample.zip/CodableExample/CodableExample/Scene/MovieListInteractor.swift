//
//  MovieListInteractor.swift
//  CodableExample
//
//  Created by Enes Urkan on 15.07.2023.
//

import Foundation

protocol MovieListBusinessLogic {
    func fetchData()
}

final class MovieListInteractor: MovieListBusinessLogic {
    // MARK: Dependencies
    private let repository: MovieListRepositoryProtocol
    private let presenter: MovieListPresentationLogic
    
    // MARK: Initializers
    init(presenter: MovieListPresentationLogic, repository: MovieListRepositoryProtocol) {
        self.presenter = presenter
        self.repository = repository
    }
    
    // MARK: Business Logic
    func fetchData() {
        repository.fetchData { [weak self] result in
            guard let self else { return }
            let response = MovieListModels.Response(result: result)
            self.presenter.present(response)
        }
    }
}
