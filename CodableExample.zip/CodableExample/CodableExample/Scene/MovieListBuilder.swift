//
//  MovieListBuilder.swift
//  CodableExample
//
//  Created by Enes Urkan on 15.07.2023.
//

import Foundation
import UIKit.UIViewController

struct MovieListBuilder {
    static func build() -> UIViewController {
        let presenter = MovieListPresenter()
        let repository = MovieListRepository(movieService: MovieService())
        let interactor = MovieListInteractor(presenter: presenter, repository: repository)
        let controller = MovieListViewController(interactor: interactor)
        
        presenter.controller = controller
        return controller
    }
}
