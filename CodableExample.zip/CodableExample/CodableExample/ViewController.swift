//
//  ViewController.swift
//  CodableExample
//
//  Created by Enes Urkan on 15.07.2023.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

