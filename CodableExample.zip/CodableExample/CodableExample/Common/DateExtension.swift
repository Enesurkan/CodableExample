//
//  DateExtension.swift
//  CodableExample
//
//  Created by Enes Urkan on 16.07.2023.
//

import Foundation

extension Date {
    func toString(dateFormat: String) -> String {
        let dateFormatter        = DateFormatter()
        dateFormatter.dateFormat = dateFormat
        dateFormatter.timeZone   = TimeZone(identifier: "Europe/Istanbul")
        dateFormatter.locale     = Locale(identifier: "tr_TR")
        return dateFormatter.string(from: self)
    }
}
