//
//  MovieListViewController.swift
//  CodableExample
//
//  Created by Enes Urkan on 15.07.2023.
//

import UIKit
import SnapKit

protocol MovieListViewControllerDisplayLogic: AnyObject {
    func display(viewModel: MovieListModels.ViewModel)
    func display(error: String)
}

final class MovieListViewController: UIViewController, MovieListViewControllerDisplayLogic {
    
    // MARK: UI Elements
    private lazy var topNotchView: UIView = {
        let view = UIView(frame: .zero)
        view.backgroundColor = .white
        return view
    }()
    
    lazy var tableView: UITableView = {
        let table = UITableView()
        table.delegate = self
        table.dataSource = self
        table.backgroundColor = .clear
        table.register(MovieTableViewCell.self, forCellReuseIdentifier: MovieTableViewCell.reuseIdentifier)
        table.rowHeight = UITableView.automaticDimension
        table.separatorStyle = .none
        return table
    }()
    
    // MARK: Private Properties
    private var cellModels = [MovieListDisplayModel]()
    
    // MARK: Dependencies
    private let interactor: MovieListBusinessLogic

    // MARK: Initializers
    init(interactor: MovieListBusinessLogic) {
        self.interactor = interactor
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError()
    }
    
    // MARK: Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        layout()
        
        interactor.fetchData()
    }

    // MARK: Setup
    private func setup() {
        view.backgroundColor = .white
        
        view.addSubview(topNotchView)
        view.addSubview(tableView)
    }
    
    private func layout() {
        topNotchView.snp.makeConstraints { (make) in
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.top)
            make.left.right.top.equalToSuperview()
        }
        
        tableView.snp.makeConstraints { make in
            make.top.equalTo(topNotchView.snp.bottom)
            make.leading.trailing.bottom.equalToSuperview()
        }
    }
    
    // MARK: Display Logic
    func display(viewModel: MovieListModels.ViewModel) {
        self.cellModels = viewModel.cellModels
        tableView.reloadData()
    }

    func display(error: String) {
        self.cellModels.removeAll()
        tableView.reloadData()
        let alertController = UIAlertController(title: "Error", message: error, preferredStyle: .alert)
        alertController.addAction(.init(title: "Kapat", style: .cancel))
        self.present(alertController, animated: true)
    }
}
// MARK: UITableViewDataSource
extension MovieListViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cellModels.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: MovieTableViewCell.reuseIdentifier, for: indexPath) as? MovieTableViewCell else { return UITableViewCell() }
        cell.configure(with: cellModels[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // Encode example
        
    }
}
