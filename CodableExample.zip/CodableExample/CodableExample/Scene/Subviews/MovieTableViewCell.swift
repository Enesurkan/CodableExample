//
//  MovieTableViewCell.swift
//  CodableExample
//
//  Created by Enes Urkan on 16.07.2023.
//

import UIKit
import SnapKit
import SDWebImage

final class MovieTableViewCell: UITableViewCell {
    // MARK: Reuse Identifier
    static let reuseIdentifier = "MovieTableViewCell"
    
    // MARK: UI Elements
    private lazy var movieImage: UIImageView = {
        let imageView = UIImageView()
        imageView.clipsToBounds = true
        imageView.backgroundColor = .clear
        return imageView
    }()
    
    lazy var movieName: UILabel = {
        let label = UILabel()
        label.textColor = .black
        label.textAlignment = .left
        label.numberOfLines = 1
        return label
    }()
    
    private lazy var movieDescriptionLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .left
        label.textColor = .black
        label.numberOfLines = .zero
        return label
    }()
    
    private lazy var dateLabel: UILabel = {
        let label = UILabel()
        label.textColor = .black
        label.textAlignment = .left
        label.numberOfLines = 1
        return label
    }()
    
    private lazy var separatorView: UIView = {
        let view = UIView()
        view.backgroundColor = .black.withAlphaComponent(0.2)
        return view
    }()
    
    // MARK: Initializers
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setup()
        layout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: Setup
    private func setup() {
        backgroundColor = .clear
        selectionStyle = .none
        
        addSubview(movieImage)
        addSubview(movieName)
        addSubview(movieDescriptionLabel)
        addSubview(dateLabel)
        addSubview(separatorView)
    }
    
    private func layout() {
        movieImage.snp.makeConstraints { make in
            make.width.equalTo(100)
            make.height.equalTo(150)
            make.top.equalTo(10)
            make.left.equalTo(10)
            make.bottom.equalTo(-10)
        }
        
        movieName.snp.makeConstraints { make in
            make.left.equalTo(movieImage.snp.right).offset(10)
            make.top.equalTo(7)
            make.right.equalTo(-8)
            make.height.equalTo(16)
        }

        movieDescriptionLabel.snp.makeConstraints { make in
            make.left.equalTo(movieImage.snp.right).offset(8)
            make.top.equalTo(movieName.snp.bottom).offset(4)
            make.right.equalTo(-8)
            make.bottom.equalTo(dateLabel.snp.top).offset(-4)
        }
        
        dateLabel.snp.makeConstraints { make in
            make.left.equalTo(movieImage.snp.right).offset(8)
            make.right.equalTo(-8)
            make.bottom.equalTo(-8)
            make.height.equalTo(16)
        }

        separatorView.snp.makeConstraints { make in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(1)
        }
    }
    
    // MARK: - Override Methods
    override func layoutSubviews() {
        super.layoutSubviews()
        movieImage.layer.cornerRadius = 10
    }
    
    // MARK: - Public Methods
    func configure(with displayModel: MovieListDisplayModel) {
        movieImage.sd_setImage(with: displayModel.imageURL)
        movieName.text = displayModel.movieName
        movieDescriptionLabel.text = displayModel.moviewDescription
        dateLabel.text = displayModel.date
    }
}
