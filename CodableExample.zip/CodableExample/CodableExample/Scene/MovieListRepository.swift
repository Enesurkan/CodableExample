//
//  MovieListNetworkWorker.swift
//  CodableExample
//
//  Created by Enes Urkan on 15.07.2023.
//

import Foundation

protocol MovieListRepositoryProtocol {
    func fetchData(completion: (Result<[Movie], MovieService.DecodeError>) -> Void)
}

final class MovieListRepository: MovieListRepositoryProtocol {
    private let movieService: MovieService
    
    init(movieService: MovieService) {
        self.movieService = movieService
    }
    
    func fetchData(completion: (Result<[Movie], MovieService.DecodeError>) -> Void) {
        self.movieService.getMovieList(completion: completion)
    }
}
