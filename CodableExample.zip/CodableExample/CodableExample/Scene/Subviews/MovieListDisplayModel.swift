//
//  MovieListDisplayModel.swift
//  CodableExample
//
//  Created by Enes Urkan on 16.07.2023.
//

import Foundation

struct MovieListDisplayModel {
    let imageURL: URL?
    let movieName: String
    let moviewDescription: String
    let date: String?
    
    // MARK: Lifecycle
    init(movie: Movie) {
        self.imageURL = movie.posterUrl
        self.movieName = movie.title
        self.moviewDescription = movie.plot
        self.date = movie.date?.toString(dateFormat: "dd.MM.yyyy")
    }
}
